const $ = id => document.getElementById(id);

const I18N = {
  ar: {
    appName:"متتبع المصاريف", install:"📲 تثبيت التطبيق", heroTitle:"سيطر على مصاريفك بسهولة.",
    heroText:"أضف دخلك ومصاريفك الثابتة واليومية وشاهد الرصيد والميزانية بشكل فوري.",
    currentMonth:"الشهر الحالي", balance:"الرصيد الحالي", income:"إجمالي الدخل", expenses:"إجمالي المصاريف",
    monthlyIncome:"المدخول الشهري", amount:"المبلغ", saveIncome:"حفظ المدخول", monthIncomeTotal:"إجمالي الدخل لهذا الشهر",
    fixedExpenses:"المصاريف الثابتة", saveFixed:"حفظ المصاريف الثابتة", fixedTotal:"إجمالي المصاريف الثابتة",
    dailyExpenses:"المصاريف اليومية", category:"الفئة", description:"الوصف", date:"التاريخ", saveDaily:"حفظ المصروف اليومي",
    dailyTotal:"إجمالي المصاريف اليومية", budget:"الميزانية الشهرية", save:"حفظ", currencyRates:"العملة وأسعار الصرف",
    ratesHelp:"قيمة كل عملة مقابل 1 USD.", baseCurrency:"العملة الأساسية", saveSettings:"حفظ الإعدادات",
    report:"التقرير", history:"سجل العمليات", clearAll:"حذف الكل", empty:"لا توجد عمليات لهذا الشهر.",
    descriptionPlaceholder:"مثال: غداء", previous:"الشهر السابق", next:"الشهر التالي", noBudget:"لم يتم تحديد ميزانية بعد.",
    budgetUsed:"المستخدم", remaining:"المتبقي", overBudget:"⚠️ لقد تجاوزت الميزانية المحددة.", withinBudget:"أنت ضمن الميزانية. ممتاز!",
    delete:"حذف", incomeType:"دخل", expenseType:"مصروف", confirm:"هل تريد حذف كل عمليات هذا الشهر؟", saved:"تم الحفظ."
  },
  en: {
    appName:"Expense Tracker", install:"📲 Install App", heroTitle:"Control your money easily.",
    heroText:"Add your income, fixed expenses and daily expenses and see your balance and budget instantly.",
    currentMonth:"Current Month", balance:"Current Balance", income:"Total Income", expenses:"Total Expenses",
    monthlyIncome:"Monthly Income", amount:"Amount", saveIncome:"Save Income", monthIncomeTotal:"Total Income This Month",
    fixedExpenses:"Fixed Expenses", saveFixed:"Save Fixed Expenses", fixedTotal:"Total Fixed Expenses",
    dailyExpenses:"Daily Expenses", category:"Category", description:"Description", date:"Date", saveDaily:"Save Daily Expense",
    dailyTotal:"Total Daily Expenses", budget:"Monthly Budget", save:"Save", currencyRates:"Currency & Exchange Rates",
    ratesHelp:"Value of each currency against 1 USD.", baseCurrency:"Base Currency", saveSettings:"Save Settings",
    report:"Report", history:"Transactions History", clearAll:"Clear All", empty:"No transactions for this month.",
    descriptionPlaceholder:"Example: Lunch", previous:"Previous Month", next:"Next Month", noBudget:"No budget set.",
    budgetUsed:"Used", remaining:"Remaining", overBudget:"⚠️ You exceeded the selected budget.", withinBudget:"You are within the budget. Great!",
    delete:"Delete", incomeType:"Income", expenseType:"Expense", confirm:"Delete all transactions for this month?", saved:"Saved."
  }
};

const FIXED = [
  ["rent","إيجار","Rent"],["electricity","كهرباء","Electricity"],["water","ماء","Water"],
  ["internet","إنترنت","Internet"],["phone","هاتف","Phone"],["subscriptions","اشتراكات","Subscriptions"],["other","أخرى","Other"]
];
const DAILY = [["food","طعام","Food"],["coffee","قهوة","Coffee"],["transport","مواصلات","Transport"],["shopping","تسوق","Shopping"],["entertainment","ترفيه","Entertainment"],["health","صحة","Health"],["other","أخرى","Other"]];

const defaultState = {
  language:"ar", baseCurrency:"USD",
  rates:{USD:1, LBP:89500, SYP:13000, CAD:1.35},
  months:{}
};

let state = JSON.parse(localStorage.getItem("expenseFinanceData") || "null") || defaultState;
let currentMonth = new Date().toISOString().slice(0,7);
let deferredPrompt = null;

function monthData() {
  if (!state.months[currentMonth]) state.months[currentMonth] = {income:0, incomeCurrency:"USD", fixed:{}, budget:0, budgetCurrency:"USD", transactions:[]};
  return state.months[currentMonth];
}
function saveState(){ localStorage.setItem("expenseFinanceData", JSON.stringify(state)); }
function rate(currency){ return Number(state.rates[currency] || 1); }
function toUSD(amount,currency){ return Number(amount||0) / rate(currency); }
function money(value){
  const cur = state.baseCurrency || "USD";
  const converted = Number(value||0) * rate(cur);
  return new Intl.NumberFormat(state.language==="ar"?"ar-LB":"en-US",{style:"currency",currency:cur,maximumFractionDigits:2}).format(converted);
}
function monthName(){
  const d = new Date(currentMonth+"-01T12:00:00");
  return new Intl.DateTimeFormat(state.language==="ar"?"ar-LB":"en-US",{month:"long",year:"numeric"}).format(d);
}
function t(k){ return I18N[state.language][k] || k; }

function applyLanguage(){
  document.documentElement.lang = state.language;
  document.documentElement.dir = state.language==="ar" ? "rtl":"ltr";
  document.title = t("appName");
  document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t(el.dataset.i18n));
  document.querySelectorAll("[data-ph]").forEach(el=>el.placeholder=t(el.dataset.ph));
  $("langBtn").textContent = state.language==="ar" ? "EN" : "عربي";
  renderSelectors();
  render();
}

function fillSelect(id, items){
  const el=$(id), old=el.value;
  el.innerHTML="";
  items.forEach(([value,ar,en])=>{
    const o=document.createElement("option"); o.value=value; o.textContent=state.language==="ar"?ar:en; el.appendChild(o);
  });
  if([...el.options].some(o=>o.value===old)) el.value=old;
}
function renderSelectors(){
  const currencies = [["USD","USD","USD"],["LBP","LBP","LBP"],["SYP","SYP","SYP"],["CAD","CAD","CAD"]];
  fillSelect("incomeCurrency",currencies); fillSelect("budgetCurrency",currencies); fillSelect("baseCurrency",currencies);
  $("baseCurrency").value=state.baseCurrency;
  fillSelect("dailyCategory",DAILY);
}
function renderFixed(){
  const d=monthData(), wrap=$("fixedList"); wrap.innerHTML="";
  FIXED.forEach(([key,ar,en])=>{
    const row=document.createElement("div"); row.className="fixed-row";
    row.innerHTML=`<label>${state.language==="ar"?ar:en}</label><div class="money-row"><input class="fixed-input" data-key="${key}" type="number" min="0" step="0.01" value="${d.fixed[key]||""}" placeholder="0"><select class="fixed-currency" data-key="${key}"><option value="USD">USD</option><option value="LBP">LBP</option><option value="SYP">SYP</option><option value="CAD">CAD</option></select></div>`;
    wrap.appendChild(row);
  });
}
function renderRates(){
  const wrap=$("ratesList"); wrap.innerHTML="";
  [["USD","🇺🇸"],["LBP","🇱🇧"],["SYP","🇸🇾"],["CAD","🇨🇦"]].forEach(([c,flag])=>{
    const row=document.createElement("div"); row.className="rate-row";
    row.innerHTML=`<span>${flag} ${c}</span><input class="rate-input" data-currency="${c}" type="number" min="0.000001" step="any" value="${state.rates[c]}"><b>${c}</b>`;
    wrap.appendChild(row);
  });
}
function calc(){
  const d=monthData();
  const income=toUSD(d.income,d.incomeCurrency);
  const fixed=Object.values(d.fixed||{}).reduce((s,x)=>s+toUSD(x.amount||x, x.currency||"USD"),0);
  const daily=d.transactions.filter(x=>x.type==="expense").reduce((s,x)=>s+toUSD(x.amount,x.currency),0);
  const txIncome=d.transactions.filter(x=>x.type==="income").reduce((s,x)=>s+toUSD(x.amount,x.currency),0);
  const totalIncome=income+txIncome;
  const totalExpense=fixed+daily;
  return {income:totalIncome,fixed,daily,expense:totalExpense,balance:totalIncome-totalExpense};
}
function render(){
  const d=monthData(), c=calc();
  $("monthLabel").textContent=monthName();
  $("incomeAmount").value=d.income||"";
  $("incomeCurrency").value=d.incomeCurrency||"USD";
  $("budget").value=d.budget||"";
  $("budgetCurrency").value=d.budgetCurrency||"USD";
  $("dailyDate").value=$("dailyDate").value || new Date().toISOString().slice(0,10);
  $("balance").textContent=money(c.balance); $("income").textContent=money(c.income); $("expense").textContent=money(c.expense);
  $("incomeMonthTotal").textContent=money(c.income);
  $("fixedTotal").textContent=money(c.fixed); $("dailyTotal").textContent=money(c.daily);
  $("reportIncome").textContent=money(c.income); $("reportFixed").textContent=money(c.fixed); $("reportDaily").textContent=money(c.daily); $("reportBalance").textContent=money(c.balance);
  renderFixed(); renderRates(); renderTransactions();
  const budgetUSD=toUSD(d.budget,d.budgetCurrency);
  const used=budgetUSD ? c.expense/budgetUSD*100 : 0;
  $("progressBar").style.width=Math.min(100,Math.max(0,used))+"%";
  $("budgetText").textContent=budgetUSD ? `${t("budgetUsed")}: ${Math.round(used)}% • ${t("remaining")}: ${money(budgetUSD-c.expense)}` : t("noBudget");
  $("alertBox").classList.toggle("hidden",!budgetUSD);
  if(budgetUSD){ $("alertBox").textContent=c.expense>budgetUSD?t("overBudget"):t("withinBudget"); $("alertBox").className="alert "+(c.expense>budgetUSD?"bad":"good"); }
}
function renderTransactions(){
  const list=$("transactions"), d=monthData(); list.innerHTML="";
  if(!d.transactions.length){ $("empty").classList.remove("hidden"); return; }
  $("empty").classList.add("hidden");
  [...d.transactions].reverse().forEach((x)=>{
    const row=document.createElement("div"); row.className="transaction";
    row.innerHTML=`<div class="info"><div class="icon">${x.type==="income"?"💰":"💸"}</div><div><b>${escapeHtml(x.description)}</b><small>${x.date} • ${escapeHtml(x.category||"")}</small></div></div><div class="tx-right"><b class="${x.type==="income"?"amount-income":"amount-expense"}">${x.type==="income"?"+":"-"}${money(toUSD(x.amount,x.currency))}</b><button class="delete" aria-label="${t("delete")}">✕</button></div>`;
    row.querySelector(".delete").onclick=()=>{ d.transactions.splice(d.transactions.indexOf(x),1); saveState(); render(); };
    list.appendChild(row);
  });
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

$("saveIncome").onclick=()=>{const d=monthData(); d.income=Math.max(0,Number($("incomeAmount").value)||0); d.incomeCurrency=$("incomeCurrency").value; saveState(); render();};
$("saveFixed").onclick=()=>{
  const d=monthData(); d.fixed={};
  document.querySelectorAll(".fixed-input").forEach(input=>{d.fixed[input.dataset.key]={amount:Math.max(0,Number(input.value)||0),currency:"USD"};});
  saveState(); render();
};
$("saveDaily").onclick=()=>{
  const amount=Number($("dailyAmount").value), desc=$("dailyDescription").value.trim(), date=$("dailyDate").value;
  if(!amount||amount<=0||!desc||!date)return;
  monthData().transactions.push({type:"expense",description:desc,category:$("dailyCategory").value,amount,currency:state.baseCurrency,date});
  saveState(); $("dailyAmount").value=""; $("dailyDescription").value=""; render();
};
$("saveBudget").onclick=()=>{const d=monthData(); d.budget=Math.max(0,Number($("budget").value)||0); d.budgetCurrency=$("budgetCurrency").value; saveState(); render();};
$("saveSettings").onclick=()=>{
  document.querySelectorAll(".rate-input").forEach(i=>state.rates[i.dataset.currency]=Math.max(.000001,Number(i.value)||1));
  state.baseCurrency=$("baseCurrency").value; saveState(); render();
};
$("prevMonth").onclick=()=>{const d=new Date(currentMonth+"-01T12:00:00");d.setMonth(d.getMonth()-1);currentMonth=d.toISOString().slice(0,7);render();};
$("nextMonth").onclick=()=>{const d=new Date(currentMonth+"-01T12:00:00");d.setMonth(d.getMonth()+1);currentMonth=d.toISOString().slice(0,7);render();};
$("clearAll").onclick=()=>{if(monthData().transactions.length&&confirm(t("confirm"))){monthData().transactions=[];saveState();render();}};
$("langBtn").onclick=()=>{state.language=state.language==="ar"?"en":"ar";saveState();applyLanguage();};

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").classList.remove("hidden");});
$("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").classList.add("hidden");};

if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(console.log));

/* Migrate the old simple version without deleting it. */
(function migrateOld(){
  if(localStorage.getItem("expenseMigrationDone")) return;
  const old=JSON.parse(localStorage.getItem("expenseTransactions")||"[]");
  const oldBudget=Number(localStorage.getItem("expenseBudget")||0);
  if(old.length||oldBudget){
    const d=monthData();
    old.forEach(x=>d.transactions.push({...x,currency:"USD",category:"other"}));
    if(oldBudget)d.budget=oldBudget;
    saveState();
  }
  localStorage.setItem("expenseMigrationDone","1");
})();

applyLanguage();
